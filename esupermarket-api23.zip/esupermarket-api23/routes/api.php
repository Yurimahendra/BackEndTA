<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::apiResources([
    'datapenjual' => 'Api\DataPenjualController',
    'dataproduk' => 'Api\DataProdukController',
    'datakurir' => 'Api\DataKurirController',
    'datapembeli' => 'Api\DataPembeliController',
    'dataorderan' => 'Api\DataOrderanController',
    'datakeranjang' => 'Api\DataKeranjangController'
]);

//Route::get('/api/dataproduk', [Api\DataProdukController::class, 'index']);

//Route::post('api/dataproduk/{dataproduk}', [Api\DataProdukController::class, 'destroy']);